#ng-notify changelog

##v0.5.0
- **new feature**: added a dismiss method to give additional dev control over how notifications display.

##v0.4.2
- update for version bumps
- same pathing fix for the package.json file.

##v0.4.1
- pathing fix for bower, bower.json file.

##v0.4.0
- **new feature**: sticky notifications, dismissable by the user
- standardized comments throughout module
- organized module structure

##v0.3.0
- **new feature**: configurable options for individual notifications
- renamed type option from *defaultType* to just *type* for consistency
- introduced changelog

##v0.2.1
- better organized for bower distribution

##v0.2.0
- initial bower release
